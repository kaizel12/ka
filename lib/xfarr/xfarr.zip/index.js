// Jan dijual ngentod (cr xfar)

const Functions = require('./lib/functions.js')
global.fc = new Functions();

module.exports.anime = require('./lib/anime.js')
module.exports.downloader = require('./lib/downloader.js')
module.exports.information = require('./lib/information.js')
module.exports.islami = require('./lib/islami.js')
module.exports.maker = require('./lib/maker.js')
module.exports.search = require('./lib/search.js')
module.exports.tools = require('./lib/tools.js')